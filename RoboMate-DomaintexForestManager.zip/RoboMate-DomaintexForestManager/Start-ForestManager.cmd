@echo off
rem RoboMate Domaintex Forest Manager - web console
rem Run from an elevated prompt on the migration server, as the account that runs the migration scripts.
rem Needs the ASP.NET Core 8 Runtime (https://dotnet.microsoft.com/download/dotnet/8.0).
cd /d "%~dp0"
title RoboMate Domaintex Forest Manager
if exist RoboMateForestManager.exe (
  RoboMateForestManager.exe %*
) else (
  dotnet RoboMateForestManager.dll %*
)
if errorlevel 1 pause
